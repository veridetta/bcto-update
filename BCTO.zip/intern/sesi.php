<div class="card">
    <div class="card-header">
        <p class="h4">Penalaran Umum</p>
    </div>
    <div class="card-body">
        <div class="col-12 row row-imbang" data-toggle="collapse" href="#collapse1">
            <div class="col-6">
                <p class="h7">Nomor 1 &nbsp;&nbsp;&nbsp;<button class="button btn btn-success">A</button>
                <button class="button btn btn-secondary" style="margin-right:3px;"><i class="fa fa-edit"></i></button></p>
                <p class="h7">Nomor 2 &nbsp;&nbsp;&nbsp;<button class="button btn btn-success">A</button>
                <button class="button btn btn-secondary" style="margin-right:3px;"><i class="fa fa-edit"></i></button></p>
            </div>
            <div class="col-6">
                <p class="h7">Nomor 11 &nbsp;&nbsp;&nbsp;<button class="button btn btn-success">A</button>
                <button class="button btn btn-secondary" style="margin-right:3px;"><i class="fa fa-edit"></i></button></p>
                <p class="h7">Nomor 12 &nbsp;&nbsp;&nbsp;<button class="button btn btn-success">A</button>
                <button class="button btn btn-secondary" style="margin-right:3px;"><i class="fa fa-edit"></i></button></p>
            </div>
        </div>
        <hr>
    </div>
    <div class="card-footer">
        <div class="col-12 row justify-content-center h-60">
            <div class="my-auto">
                <button class="btn button btn-success" id="tambah-soal" href="soal" sesi="<?php echo $_GET['sesi'];?>"><i class="fa fa-plus"></i> Tambah Soal</button>
            </div>
        </div>
    </div>
<div>