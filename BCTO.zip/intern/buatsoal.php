buat soal
<?php echo $_GET['sesi'];?>
<textarea name="editor1"></textarea>