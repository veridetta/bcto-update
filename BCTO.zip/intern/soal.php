<div class="card">
    <div class="card-header">
        <p class="h4">Menu Soal</p>
    </div>
    <div class="card-body">
        <div class="col-12 row row-imbang" data-toggle="collapse" href="#collapse1">
            <div class="col-6">
                <p class="h5">BaseCamp UTBK1</p>
                <label class="text-muted">01 - 05 Oktober 2020</label>
            </div>
            <div class="col-6 text-right">
                <p class="h6">120 Soal</p>
                <span class="text-muted">Pilihan Ganda</span>
            </div>
        </div>
        <div class="col-12 panel-collapse collapse" id="collapse1">
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td>Penalaran Umum</td>
                        <td>20 Soal</td>
                        <td><button class="btn button btn-primary pilih-sesi" sesi="puutbk01" href="soal"><i class="fa fa-edit"></i></button></td>
                    </tr>
                    <tr>
                        <td>Penalaran Umum</td>
                        <td>20 Soal</td>
                        <td><button class="btn button btn-primary"><i class="fa fa-edit"></i></button></td>
                    </tr>
                    <tr>
                        <td>Penalaran Umum</td>
                        <td>20 Soal</td>
                        <td><button class="btn button btn-primary"><i class="fa fa-edit"></i></button></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <hr>
        <div class="col-12 row justify-content-center h-60">
            <div class="my-auto">
                <p class="text-muted">Tidak ada paket soal</p>
                <button class="btn button btn-success"><i class="fa fa-plus"></i> Buat Paket Soal</button>
            </div>
        </div>
    </div>
    <div class="card-footer">
    </div>
<div>
