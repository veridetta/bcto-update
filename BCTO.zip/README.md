# BCTO
strip
