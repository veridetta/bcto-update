<!-- Sidebar -->
<div class="bg-light border-right" id="sidebar-wrapper">
        <div class="sidebar-heading">Menu Utama </div>
        <div class="list-group list-group-flush">
            <a href="dashboard" class="list-group-item list-group-item-action bg-light">Dashboard</a>
            <a href="soal" class="list-group-item list-group-item-action bg-light">Soal</a>
            <!--
            <div id="accordion">
                <div class="card">
                    <div class="card-header">
                    <a class="card-link" style="color:#000;" data-toggle="collapse" href="#collapseOne">
                        Soal
                    </a>
                    </div>
                    <div id="collapseOne" class="collapse show" data-parent="#accordion">
                        <div class="card-body">
                            <a href="#" class="list-group-item list-group-item-action bg-light">Paket Soal</a>
                        </div>
                    </div>
                </div>
            </div>
            !-->
            <a href="siswa" class="list-group-item list-group-item-action bg-light">Siswa</a>
            <a href="pembayaran.php" class="list-group-item list-group-item-action bg-light">Pembayaran</a>
            <a href="#" class="list-group-item list-group-item-action bg-light">Status</a>
        </div>
        </div>
        <!-- /#sidebar-wrapper -->